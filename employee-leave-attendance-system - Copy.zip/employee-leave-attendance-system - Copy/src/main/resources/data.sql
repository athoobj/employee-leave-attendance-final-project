-- =========================================================
-- Employee Leave and Attendance System
-- Sample Data
-- =========================================================

-- =========================
-- Employees
-- =========================
INSERT INTO employees
(employee_number, full_name, email, department, active)
VALUES
    ('EMP001', 'Ahmed Ali', 'ahmed.ali@company.com', 'IT', true),
    ('EMP002', 'Sara Mohammed', 'sara.mohammed@company.com', 'Human Resources', true),
    ('EMP003', 'Khalid Hassan', 'khalid.hassan@company.com', 'Finance', true),
    ('EMP004', 'Noura Abdullah', 'noura.abdullah@company.com', 'Operations', true)
    ON DUPLICATE KEY UPDATE
                         full_name = VALUES(full_name),
                         department = VALUES(department),
                         active = VALUES(active);

-- =========================
-- Leave Types
-- =========================
INSERT INTO leave_types
(name, description, maximum_days, active)
VALUES
    ('Annual Leave', 'Paid annual leave', 30, true),
    ('Sick Leave', 'Medical leave', 15, true),
    ('Emergency Leave', 'Emergency situations', 5, true),
    ('Unpaid Leave', 'Leave without salary', 20, true)
    ON DUPLICATE KEY UPDATE
                         description = VALUES(description),
                         maximum_days = VALUES(maximum_days),
                         active = VALUES(active);

-- =========================
-- Leave Requests
-- =========================
INSERT INTO leave_requests
(employee_id, leave_type_id, start_date, end_date, reason, status)
VALUES
    (1,1,'2026-07-28','2026-07-30','Family Vacation','PENDING'),
    (2,2,'2026-07-20','2026-07-21','Medical Appointment','APPROVED'),
    (3,3,'2026-07-15','2026-07-15','Emergency','REJECTED')
    ON DUPLICATE KEY UPDATE
                         status = VALUES(status);

-- =========================
-- Attendance Records
-- =========================
INSERT INTO attendance_records
(employee_id, attendance_date, check_in_time, check_out_time, status, notes)
VALUES
    (1,'2026-07-24','08:00:00','16:00:00','PRESENT','Completed working day'),
    (2,'2026-07-24','08:30:00','16:30:00','LATE','Late arrival'),
    (3,'2026-07-24',NULL,NULL,'ABSENT','Absent'),
    (4,'2026-07-24',NULL,NULL,'ON_LEAVE','Annual Leave')
    ON DUPLICATE KEY UPDATE
                         notes = VALUES(notes);

-- =========================
-- Spring Security Users
-- =========================
INSERT INTO users (username, password, enabled, employee_id)
VALUES
      ('employee', '$2y$10$.i0XbwiESE7n.4Hq2PxmDeDS3dUhsABnWOOEJjS9xjQo9XTPM.DmG', true, 1),
      ('hr', '$2y$10$SQXijlLwSx31WTtPfKLFmOyhDGtvQWwta29dxaPqesFnwEhmpDVZu', true, NULL),
      ('admin', '$2y$10$tsKzmoFaCUnvdDwCo3uZu.jd9ha92dj9yEOurqQ6SZaZLIFMUdEfW', true, NULL)
    ON DUPLICATE KEY UPDATE
        password = VALUES(password),
        enabled = VALUES(enabled),
        employee_id = VALUES(employee_id);
-- =========================
-- Authorities
-- =========================
INSERT IGNORE INTO authorities (username, authority)
VALUES
('employee', 'ROLE_EMPLOYEE'),
('hr', 'ROLE_HR'),
('admin', 'ROLE_ADMIN');