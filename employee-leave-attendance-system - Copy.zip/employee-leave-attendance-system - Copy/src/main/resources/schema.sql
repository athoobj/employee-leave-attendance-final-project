-- =========================================================
-- Employee Leave and Attendance System
-- Database Schema
-- =========================================================

-- ---------------------------------------------------------
-- Drop tables in reverse relationship order
-- ---------------------------------------------------------

DROP TABLE IF EXISTS authorities;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS attendance_records;
DROP TABLE IF EXISTS leave_requests;
DROP TABLE IF EXISTS leave_types;
DROP TABLE IF EXISTS employees;


-- ---------------------------------------------------------
-- Employees Table
-- ---------------------------------------------------------

CREATE TABLE employees (
                           id BIGINT AUTO_INCREMENT PRIMARY KEY,
                           employee_number VARCHAR(255) NOT NULL,
                           full_name VARCHAR(255) NOT NULL,
                           email VARCHAR(255) NOT NULL,
                           department VARCHAR(255) NOT NULL,
                           active BOOLEAN NOT NULL DEFAULT TRUE,

                           CONSTRAINT uk_employees_employee_number
                               UNIQUE (employee_number),

                           CONSTRAINT uk_employees_email
                               UNIQUE (email)
);


-- ---------------------------------------------------------
-- Leave Types Table
-- ---------------------------------------------------------

CREATE TABLE leave_types (
                             id BIGINT AUTO_INCREMENT PRIMARY KEY,
                             name VARCHAR(255) NOT NULL,
                             description VARCHAR(500),
                             maximum_days INT NOT NULL,
                             active BOOLEAN NOT NULL DEFAULT TRUE,

                             CONSTRAINT uk_leave_types_name
                                 UNIQUE (name)
);


-- ---------------------------------------------------------
-- Leave Requests Table
-- ---------------------------------------------------------

CREATE TABLE leave_requests (
                                id BIGINT AUTO_INCREMENT PRIMARY KEY,
                                employee_id BIGINT NOT NULL,
                                leave_type_id BIGINT NOT NULL,
                                start_date DATE NOT NULL,
                                end_date DATE NOT NULL,
                                reason VARCHAR(500),
                                status VARCHAR(50) NOT NULL DEFAULT 'PENDING',

                                CONSTRAINT fk_leave_requests_employee
                                    FOREIGN KEY (employee_id)
                                        REFERENCES employees(id),

                                CONSTRAINT fk_leave_requests_leave_type
                                    FOREIGN KEY (leave_type_id)
                                        REFERENCES leave_types(id),

                                CONSTRAINT chk_leave_request_dates
                                    CHECK (end_date >= start_date)
);


-- ---------------------------------------------------------
-- Attendance Records Table
-- ---------------------------------------------------------

CREATE TABLE attendance_records (
                                    id BIGINT AUTO_INCREMENT PRIMARY KEY,
                                    employee_id BIGINT NOT NULL,
                                    attendance_date DATE NOT NULL,
                                    check_in_time TIME,
                                    check_out_time TIME,
                                    status VARCHAR(50) NOT NULL DEFAULT 'PRESENT',
                                    notes VARCHAR(500),

                                    CONSTRAINT fk_attendance_employee
                                        FOREIGN KEY (employee_id)
                                            REFERENCES employees(id),

                                    CONSTRAINT chk_attendance_times
                                        CHECK (
                                            check_out_time IS NULL
                                                OR check_in_time IS NULL
                                                OR check_out_time >= check_in_time
                                            )
);


-- ---------------------------------------------------------
-- Spring Security Users Table
-- Required by JdbcUserDetailsManager
-- ---------------------------------------------------------

CREATE TABLE users (
    username VARCHAR(50) NOT NULL PRIMARY KEY,
    password VARCHAR(255) NOT NULL,
    enabled BOOLEAN NOT NULL,
    employee_id BIGINT NULL,

    CONSTRAINT fk_users_employee
        FOREIGN KEY (employee_id)
            REFERENCES employees(id)

);


-- ---------------------------------------------------------
-- Spring Security Authorities Table
-- ---------------------------------------------------------

CREATE TABLE authorities (
                             username VARCHAR(50) NOT NULL,
                             authority VARCHAR(50) NOT NULL,

                             CONSTRAINT fk_authorities_users
                                 FOREIGN KEY (username)
                                     REFERENCES users(username)
                                     ON DELETE CASCADE,

                             CONSTRAINT uk_authorities_username_authority
                                 UNIQUE (username, authority)
);


-- ---------------------------------------------------------
-- Helpful Indexes
-- ---------------------------------------------------------

CREATE INDEX idx_leave_requests_employee
    ON leave_requests(employee_id);

CREATE INDEX idx_leave_requests_leave_type
    ON leave_requests(leave_type_id);

CREATE INDEX idx_leave_requests_status
    ON leave_requests(status);

CREATE INDEX idx_attendance_employee
    ON attendance_records(employee_id);

CREATE INDEX idx_attendance_date
    ON attendance_records(attendance_date);