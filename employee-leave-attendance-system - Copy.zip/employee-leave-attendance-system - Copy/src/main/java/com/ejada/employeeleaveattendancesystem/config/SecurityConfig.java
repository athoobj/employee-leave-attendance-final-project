package com.ejada.employeeleaveattendancesystem.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.JdbcUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import javax.sql.DataSource;
import java.util.List;

@Configuration
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public JdbcUserDetailsManager userDetailsService(
            DataSource dataSource) {

        return new JdbcUserDetailsManager(dataSource);
    }

    @Bean
    public AuthenticationManager authenticationManager(
            AuthenticationConfiguration configuration)
            throws Exception {

        return configuration.getAuthenticationManager();
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {

        CorsConfiguration configuration =
                new CorsConfiguration();

        configuration.setAllowedOrigins(
                List.of("http://localhost:4200")
        );

        configuration.setAllowedMethods(
                List.of(
                        "GET",
                        "POST",
                        "PUT",
                        "PATCH",
                        "DELETE",
                        "OPTIONS"
                )
        );

        configuration.setAllowedHeaders(
                List.of("*")
        );

        configuration.setAllowCredentials(true);

        UrlBasedCorsConfigurationSource source =
                new UrlBasedCorsConfigurationSource();

        source.registerCorsConfiguration(
                "/**",
                configuration
        );

        return source;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(
            HttpSecurity http)
            throws Exception {

        http
                .cors(Customizer.withDefaults())

                .csrf(csrf -> csrf.disable())

                .authorizeHttpRequests(auth -> auth

                        // ========================================
                        // PUBLIC URLS
                        // ========================================

                        .requestMatchers(
                                "/swagger-ui/**",
                                "/swagger-ui.html",
                                "/v3/api-docs/**",
                                "/actuator/health",
                                "/actuator/info",
                                "/app-info",
                                "/css/**",
                                "/auth/login",
                                "/login",
                                "/error"
                        )
                        .permitAll()


                        // ========================================
                        // LEAVE REQUESTS - WORKFLOW
                        // ========================================

                        // Approve = HR / ADMIN only
                        .requestMatchers(
                                HttpMethod.PUT,
                                "/leave-requests/*/approve"
                        )
                        .hasAnyRole("HR", "ADMIN")

                        // Reject = HR / ADMIN only
                        .requestMatchers(
                                HttpMethod.PUT,
                                "/leave-requests/*/reject"
                        )
                        .hasAnyRole("HR", "ADMIN")

                        // Cancel:
                        // EMPLOYEE can cancel own request.
                        // Ownership is checked inside LeaveRequestService.
                        .requestMatchers(
                                HttpMethod.PUT,
                                "/leave-requests/*/cancel"
                        )
                        .hasAnyRole(
                                "EMPLOYEE",
                                "HR",
                                "ADMIN"
                        )

                        // Delete leave request = ADMIN ONLY
                        .requestMatchers(
                                HttpMethod.DELETE,
                                "/leave-requests/**"
                        )
                        .hasRole("ADMIN")

                        // Submit leave request
                        // EMPLOYEE can submit for own employee account.
                        // Ownership checked in LeaveRequestService.
                        .requestMatchers(
                                HttpMethod.POST,
                                "/leave-requests"
                        )
                        .hasAnyRole(
                                "EMPLOYEE",
                                "HR",
                                "ADMIN"
                        )

                        // Full update = HR / ADMIN
                        .requestMatchers(
                                HttpMethod.PUT,
                                "/leave-requests/*"
                        )
                        .hasAnyRole("HR", "ADMIN")

                        // Partial update = HR / ADMIN
                        .requestMatchers(
                                HttpMethod.PATCH,
                                "/leave-requests/*"
                        )
                        .hasAnyRole("HR", "ADMIN")

                        // Read leave requests
                        // EMPLOYEE is restricted to own records
                        // inside LeaveRequestService.
                        .requestMatchers(
                                HttpMethod.GET,
                                "/leave-requests/**"
                        )
                        .hasAnyRole(
                                "EMPLOYEE",
                                "HR",
                                "ADMIN"
                        )


                        // ========================================
                        // ATTENDANCE
                        // ========================================

                        // Check-in / Check-out
                        // EMPLOYEE can operate only on own ID.
                        // Ownership checked in AttendanceService.
                        .requestMatchers(
                                "/attendance/check-in/**",
                                "/attendance/check-out/**"
                        )
                        .hasAnyRole(
                                "EMPLOYEE",
                                "HR",
                                "ADMIN"
                        )

                        // Mark absent = HR / ADMIN only
                        .requestMatchers(
                                "/attendance/absent/**"
                        )
                        .hasAnyRole("HR", "ADMIN")

                        // Delete attendance = ADMIN ONLY
                        .requestMatchers(
                                HttpMethod.DELETE,
                                "/attendance/**"
                        )
                        .hasRole("ADMIN")

                        // Full update attendance = HR / ADMIN
                        .requestMatchers(
                                HttpMethod.PUT,
                                "/attendance/**"
                        )
                        .hasAnyRole("HR", "ADMIN")

                        // Partial update attendance = HR / ADMIN
                        .requestMatchers(
                                HttpMethod.PATCH,
                                "/attendance/**"
                        )
                        .hasAnyRole("HR", "ADMIN")

                        // Read attendance
                        // EMPLOYEE gets own records only
                        // through AttendanceService ownership checks.
                        .requestMatchers(
                                HttpMethod.GET,
                                "/attendance/**"
                        )
                        .hasAnyRole(
                                "EMPLOYEE",
                                "HR",
                                "ADMIN"
                        )


                        // ========================================
                        // EMPLOYEE MANAGEMENT
                        // ========================================

                        // Delete employee = ADMIN ONLY
                        .requestMatchers(
                                HttpMethod.DELETE,
                                "/employees/**"
                        )
                        .hasRole("ADMIN")

                        // HR / ADMIN can view and manage employees
                        .requestMatchers(
                                "/employees/**"
                        )
                        .hasAnyRole("HR", "ADMIN")


                        // ========================================
                        // LEAVE TYPES
                        // ========================================

                        // Delete leave type = ADMIN ONLY
                        .requestMatchers(
                                HttpMethod.DELETE,
                                "/leave-types/**"
                        )
                        .hasRole("ADMIN")

                        // EMPLOYEE must be able to GET leave types
                        // so Angular can load the leave type dropdown
                        // instead of hardcoding values.
                        .requestMatchers(
                                HttpMethod.GET,
                                "/leave-types/**"
                        )
                        .hasAnyRole(
                                "EMPLOYEE",
                                "HR",
                                "ADMIN"
                        )

                        // Create / Update / Patch leave types
                        // = HR / ADMIN only
                        .requestMatchers(
                                "/leave-types/**"
                        )
                        .hasAnyRole("HR", "ADMIN")


                        // ========================================
                        // FULL DASHBOARD / REPORTS
                        // ========================================

                        // Company-wide summary and reports
                        // = HR / ADMIN only
                        .requestMatchers(
                                "/summary/**"
                        )
                        .hasAnyRole("HR", "ADMIN")


                        // ========================================
                        // PERSONAL DASHBOARD
                        // ========================================

                        // Personal summary is specifically
                        // for the standard EMPLOYEE account.
                        .requestMatchers(
                                "/dashboard/personal"
                        )
                        .hasRole("EMPLOYEE")


                        // ========================================
                        // ANY OTHER REQUEST
                        // ========================================

                        .anyRequest()
                        .authenticated()
                )

                .httpBasic(Customizer.withDefaults())

                .formLogin(Customizer.withDefaults());

        return http.build();
    }
}