package com.ejada.employeeleaveattendancesystem.dto;
public record LoginResponse(
        String username,
        String role,
        Long employeeId
) {

}