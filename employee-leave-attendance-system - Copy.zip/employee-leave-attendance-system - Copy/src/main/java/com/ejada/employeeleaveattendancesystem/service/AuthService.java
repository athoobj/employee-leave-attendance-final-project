package com.ejada.employeeleaveattendancesystem.service;

import com.ejada.employeeleaveattendancesystem.dto.LoginResponse;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    private final AuthenticationManager authenticationManager;
    private final JdbcTemplate jdbcTemplate;

    public AuthService(
            AuthenticationManager authenticationManager,
            JdbcTemplate jdbcTemplate) {

        this.authenticationManager = authenticationManager;
        this.jdbcTemplate = jdbcTemplate;
    }

    public LoginResponse login(
            String username,
            String password) {

        Authentication authentication =
                authenticationManager.authenticate(
                        new UsernamePasswordAuthenticationToken(
                                username,
                                password
                        )
                );

        String role = authentication
                .getAuthorities()
                .stream()
                .findFirst()
                .map(authority ->
                        authority.getAuthority()
                                .replace("ROLE_", ""))
                .orElse("");

        Long employeeId = jdbcTemplate.query(
                """
                SELECT employee_id
                FROM users
                WHERE username = ?
                """,
                resultSet -> {
                    if (resultSet.next()) {
                        long value =
                                resultSet.getLong("employee_id");

                        return resultSet.wasNull()
                                ? null
                                : value;
                    }

                    return null;
                },
                username
        );

        return new LoginResponse(
                username,
                role,
                employeeId
        );
    }
}