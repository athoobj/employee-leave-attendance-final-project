package com.ejada.employeeleaveattendancesystem.validation;

import com.ejada.employeeleaveattendancesystem.entity.Employee;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

@Component
public class EmployeeValidator implements Validator {

    @Override
    public boolean supports(Class<?> clazz) {
        return Employee.class.equals(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {

        Employee employee = (Employee) target;

        if (employee.getFullName() != null
                && employee.getFullName().trim().isEmpty()) {

            errors.rejectValue(
                    "fullName",
                    "fullName.empty",
                    "Full name cannot be empty"
            );
        }

        if (employee.getEmployeeNumber() != null
                && employee.getEmployeeNumber().trim().isEmpty()) {

            errors.rejectValue(
                    "employeeNumber",
                    "employeeNumber.empty",
                    "Employee number cannot be empty"
            );
        }
    }
}