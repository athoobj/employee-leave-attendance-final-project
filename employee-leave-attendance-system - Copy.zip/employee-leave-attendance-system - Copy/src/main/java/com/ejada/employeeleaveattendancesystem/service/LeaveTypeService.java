package com.ejada.employeeleaveattendancesystem.service;

import com.ejada.employeeleaveattendancesystem.entity.LeaveType;
import com.ejada.employeeleaveattendancesystem.exception.ResourceNotFoundException;
import com.ejada.employeeleaveattendancesystem.repository.LeaveTypeRepository;
import com.ejada.employeeleaveattendancesystem.service.interfaces.ILeaveTypeService;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class LeaveTypeService implements ILeaveTypeService {

    private final LeaveTypeRepository leaveTypeRepository;

    public LeaveTypeService(LeaveTypeRepository leaveTypeRepository) {
        this.leaveTypeRepository = leaveTypeRepository;
    }

    @Override
    public List<LeaveType> getAllLeaveTypes(
            String sortBy,
            String direction) {

        Sort sort = direction.equalsIgnoreCase("desc")
                ? Sort.by(sortBy).descending()
                : Sort.by(sortBy).ascending();

        return leaveTypeRepository.findAll(sort);
    }

    @Override
    public LeaveType getLeaveTypeById(Long id) {

        return leaveTypeRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Leave type not found with id: " + id
                        )
                );
    }

    @Override
    public LeaveType createLeaveType(LeaveType leaveType) {

        if (leaveTypeRepository.existsByName(leaveType.getName())) {
            throw new IllegalArgumentException(
                    "Leave type name already exists"
            );
        }

        return leaveTypeRepository.save(leaveType);
    }

    @Override
    public LeaveType updateLeaveType(
            Long id,
            LeaveType updatedLeaveType) {

        LeaveType existingLeaveType =
                getLeaveTypeById(id);

        if (!existingLeaveType.getName()
                .equals(updatedLeaveType.getName())
                && leaveTypeRepository.existsByName(
                updatedLeaveType.getName()
        )) {

            throw new IllegalArgumentException(
                    "Leave type name already exists"
            );
        }

        existingLeaveType.setName(
                updatedLeaveType.getName()
        );

        existingLeaveType.setDescription(
                updatedLeaveType.getDescription()
        );

        existingLeaveType.setMaximumDays(
                updatedLeaveType.getMaximumDays()
        );

        existingLeaveType.setActive(
                updatedLeaveType.isActive()
        );

        return leaveTypeRepository.save(existingLeaveType);
    }

    @Override
    public LeaveType partiallyUpdateLeaveType(
            Long id,
            Map<String, Object> updates) {

        LeaveType leaveType =
                getLeaveTypeById(id);

        if (updates.containsKey("name")) {

            String newName =
                    updates.get("name").toString();

            if (!leaveType.getName().equals(newName)
                    && leaveTypeRepository.existsByName(newName)) {

                throw new IllegalArgumentException(
                        "Leave type name already exists"
                );
            }

            leaveType.setName(newName);
        }

        if (updates.containsKey("description")) {

            leaveType.setDescription(
                    updates.get("description") == null
                            ? null
                            : updates.get("description").toString()
            );
        }

        if (updates.containsKey("maximumDays")) {

            leaveType.setMaximumDays(
                    Integer.parseInt(
                            updates.get("maximumDays").toString()
                    )
            );
        }

        if (updates.containsKey("active")) {

            leaveType.setActive(
                    Boolean.parseBoolean(
                            updates.get("active").toString()
                    )
            );
        }

        return leaveTypeRepository.save(leaveType);
    }

    @Override
    public void deleteLeaveType(Long id) {

        LeaveType leaveType =
                getLeaveTypeById(id);

        leaveTypeRepository.delete(leaveType);
    }
}