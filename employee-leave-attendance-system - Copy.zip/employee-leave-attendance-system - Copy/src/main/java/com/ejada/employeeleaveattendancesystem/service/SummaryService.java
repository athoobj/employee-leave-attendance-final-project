package com.ejada.employeeleaveattendancesystem.service;

import com.ejada.employeeleaveattendancesystem.entity.Attendance;
import com.ejada.employeeleaveattendancesystem.entity.LeaveRequest;
import com.ejada.employeeleaveattendancesystem.entity.LeaveStatus;
import com.ejada.employeeleaveattendancesystem.repository.AttendanceRepository;
import com.ejada.employeeleaveattendancesystem.repository.EmployeeRepository;
import com.ejada.employeeleaveattendancesystem.repository.LeaveRequestRepository;
import com.ejada.employeeleaveattendancesystem.service.interfaces.ISummaryService;
import org.springframework.stereotype.Service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class SummaryService implements ISummaryService {

    private final EmployeeRepository employeeRepository;
    private final LeaveRequestRepository leaveRequestRepository;
    private final AttendanceRepository attendanceRepository;
    private final CurrentUserService currentUserService;

    public SummaryService(
            EmployeeRepository employeeRepository,
            LeaveRequestRepository leaveRequestRepository,
            AttendanceRepository attendanceRepository,
            CurrentUserService currentUserService) {

        this.employeeRepository = employeeRepository;
        this.leaveRequestRepository = leaveRequestRepository;
        this.attendanceRepository = attendanceRepository;
        this.currentUserService = currentUserService;
    }

    @Override
    public Map<String, Long> getSystemSummary() {

        Map<String, Long> summary =
                new LinkedHashMap<>();

        summary.put(
                "totalEmployees",
                employeeRepository.count()
        );

        summary.put(
                "totalLeaveRequests",
                leaveRequestRepository.count()
        );

        summary.put(
                "pendingLeaveRequests",
                leaveRequestRepository.countByStatus(
                        LeaveStatus.PENDING
                )
        );

        summary.put(
                "approvedLeaveRequests",
                leaveRequestRepository.countByStatus(
                        LeaveStatus.APPROVED
                )
        );

        summary.put(
                "rejectedLeaveRequests",
                leaveRequestRepository.countByStatus(
                        LeaveStatus.REJECTED
                )
        );

        summary.put(
                "cancelledLeaveRequests",
                leaveRequestRepository.countByStatus(
                        LeaveStatus.CANCELLED
                )
        );

        summary.put(
                "totalAttendanceRecords",
                attendanceRepository.count()
        );

        return summary;
    }

    @Override
    public Map<String, Long> getLeaveStatusReport() {

        Map<String, Long> report =
                new LinkedHashMap<>();

        report.put(
                "PENDING",
                leaveRequestRepository.countByStatus(
                        LeaveStatus.PENDING
                )
        );

        report.put(
                "APPROVED",
                leaveRequestRepository.countByStatus(
                        LeaveStatus.APPROVED
                )
        );

        report.put(
                "REJECTED",
                leaveRequestRepository.countByStatus(
                        LeaveStatus.REJECTED
                )
        );

        report.put(
                "CANCELLED",
                leaveRequestRepository.countByStatus(
                        LeaveStatus.CANCELLED
                )
        );

        return report;
    }

    @Override
    public Map<String, Long> getAttendanceByEmployeeReport() {

        List<Attendance> records =
                attendanceRepository.findAll();

        return records.stream()
                .collect(
                        Collectors.groupingBy(
                                attendance ->
                                        attendance
                                                .getEmployee()
                                                .getFullName(),
                                LinkedHashMap::new,
                                Collectors.counting()
                        )
                );
    }

    @Override
    public Map<String, Long> getPersonalSummary() {

        Long employeeId =
                currentUserService
                        .getCurrentEmployeeId();

        if (employeeId == null) {
            throw new IllegalArgumentException(
                    "Employee account is not linked to an employee record"
            );
        }

        List<LeaveRequest> leaveRequests =
                leaveRequestRepository
                        .findByEmployeeId(employeeId);

        List<Attendance> attendanceRecords =
                attendanceRepository
                        .findByEmployeeId(employeeId);

        Map<String, Long> summary =
                new LinkedHashMap<>();

        summary.put(
                "myLeaveRequests",
                (long) leaveRequests.size()
        );

        summary.put(
                "myPendingLeaveRequests",
                leaveRequests.stream()
                        .filter(request ->
                                request.getStatus()
                                        == LeaveStatus.PENDING)
                        .count()
        );

        summary.put(
                "myApprovedLeaveRequests",
                leaveRequests.stream()
                        .filter(request ->
                                request.getStatus()
                                        == LeaveStatus.APPROVED)
                        .count()
        );

        summary.put(
                "myRejectedLeaveRequests",
                leaveRequests.stream()
                        .filter(request ->
                                request.getStatus()
                                        == LeaveStatus.REJECTED)
                        .count()
        );

        summary.put(
                "myCancelledLeaveRequests",
                leaveRequests.stream()
                        .filter(request ->
                                request.getStatus()
                                        == LeaveStatus.CANCELLED)
                        .count()
        );

        summary.put(
                "myAttendanceRecords",
                (long) attendanceRecords.size()
        );

        return summary;
    }
}