package com.ejada.employeeleaveattendancesystem.controller;

import com.ejada.employeeleaveattendancesystem.entity.Employee;
import com.ejada.employeeleaveattendancesystem.service.EmployeeService;
import com.ejada.employeeleaveattendancesystem.validation.EmployeeValidator;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/employees")
public class EmployeeController {

    private final EmployeeService employeeService;
    private final EmployeeValidator employeeValidator;

    public EmployeeController(
            EmployeeService employeeService,
            EmployeeValidator employeeValidator) {

        this.employeeService = employeeService;
        this.employeeValidator = employeeValidator;
    }

    @InitBinder("employee")
    public void initEmployeeBinder(WebDataBinder binder) {
        binder.addValidators(employeeValidator);
    }

    @GetMapping
    public List<Employee> getAllEmployees(
            @RequestParam(defaultValue = "id") String sortBy,
            @RequestParam(defaultValue = "asc") String direction) {

        return employeeService.getAllEmployees(sortBy, direction);
    }

    @GetMapping("/{id}")
    public Employee getEmployeeById(@PathVariable Long id) {
        return employeeService.getEmployeeById(id);
    }

    @PostMapping
    public Employee createEmployee(@Valid @RequestBody Employee employee) {
        return employeeService.createEmployee(employee);
    }

    @PutMapping("/{id}")
    public Employee updateEmployee(
            @PathVariable Long id,
            @Valid @RequestBody Employee employee) {

        return employeeService.updateEmployee(id, employee);
    }

    @DeleteMapping("/{id}")
    public String deleteEmployee(@PathVariable Long id) {

        employeeService.deleteEmployee(id);
        return "Employee deleted successfully";
    }

    @PatchMapping("/{id}")
    public ResponseEntity<Employee> partiallyUpdateEmployee(
            @PathVariable Long id,
            @RequestBody Map<String, Object> updates) {

        Employee updatedEmployee = employeeService.partiallyUpdateEmployee(id, updates);
        return ResponseEntity.ok(updatedEmployee);
    }
}