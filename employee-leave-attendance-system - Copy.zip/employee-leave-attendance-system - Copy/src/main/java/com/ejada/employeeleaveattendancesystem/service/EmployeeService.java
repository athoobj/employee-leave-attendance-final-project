package com.ejada.employeeleaveattendancesystem.service;

import com.ejada.employeeleaveattendancesystem.entity.Employee;
import com.ejada.employeeleaveattendancesystem.exception.ResourceNotFoundException;
import com.ejada.employeeleaveattendancesystem.repository.EmployeeRepository;
import com.ejada.employeeleaveattendancesystem.service.interfaces.EmployeeServiceInterface;
import org.springframework.context.annotation.Primary;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Primary
@Service
public class EmployeeService implements EmployeeServiceInterface {

    private final EmployeeRepository employeeRepository;

    public EmployeeService(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    @Override
    public List<Employee> getAllEmployees(
            String sortBy,
            String direction) {

        Sort sort = direction.equalsIgnoreCase("desc")
                ? Sort.by(sortBy).descending()
                : Sort.by(sortBy).ascending();

        return employeeRepository.findAll(sort);
    }

    @Override
    public Employee getEmployeeById(Long id) {

        return employeeRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Employee not found with id: " + id
                        )
                );
    }

    @Override
    public Employee createEmployee(Employee employee) {

        validateUniqueEmployeeNumber(
                employee.getEmployeeNumber(),
                null
        );

        validateUniqueEmail(
                employee.getEmail(),
                null
        );

        return employeeRepository.save(employee);
    }

    @Override
    public Employee updateEmployee(
            Long id,
            Employee updatedEmployee) {

        Employee existingEmployee =
                getEmployeeById(id);

        validateUniqueEmployeeNumber(
                updatedEmployee.getEmployeeNumber(),
                id
        );

        validateUniqueEmail(
                updatedEmployee.getEmail(),
                id
        );

        existingEmployee.setEmployeeNumber(
                updatedEmployee.getEmployeeNumber()
        );

        existingEmployee.setFullName(
                updatedEmployee.getFullName()
        );

        existingEmployee.setEmail(
                updatedEmployee.getEmail()
        );

        existingEmployee.setDepartment(
                updatedEmployee.getDepartment()
        );

        existingEmployee.setActive(
                updatedEmployee.isActive()
        );

        return employeeRepository.save(existingEmployee);
    }

    @Override
    public void deleteEmployee(Long id) {

        Employee employee =
                getEmployeeById(id);

        employeeRepository.delete(employee);
    }

    @Override
    public Employee partiallyUpdateEmployee(
            Long id,
            Map<String, Object> updates) {

        Employee employee =
                getEmployeeById(id);

        if (updates.containsKey("employeeNumber")) {

            String newEmployeeNumber =
                    updates.get("employeeNumber").toString();

            validateUniqueEmployeeNumber(
                    newEmployeeNumber,
                    id
            );

            employee.setEmployeeNumber(
                    newEmployeeNumber
            );
        }

        if (updates.containsKey("fullName")) {
            employee.setFullName(
                    updates.get("fullName").toString()
            );
        }

        if (updates.containsKey("email")) {

            String newEmail =
                    updates.get("email").toString();

            validateUniqueEmail(
                    newEmail,
                    id
            );

            employee.setEmail(
                    newEmail
            );
        }

        if (updates.containsKey("department")) {
            employee.setDepartment(
                    updates.get("department").toString()
            );
        }

        if (updates.containsKey("active")) {
            employee.setActive(
                    Boolean.parseBoolean(
                            updates.get("active").toString()
                    )
            );
        }

        return employeeRepository.save(employee);
    }

    private void validateUniqueEmployeeNumber(
            String employeeNumber,
            Long currentEmployeeId) {

        employeeRepository
                .findByEmployeeNumber(employeeNumber)
                .ifPresent(existingEmployee -> {

                    if (currentEmployeeId == null
                            || !existingEmployee.getId()
                            .equals(currentEmployeeId)) {

                        throw new IllegalArgumentException(
                                "Employee number already exists"
                        );
                    }
                });
    }

    private void validateUniqueEmail(
            String email,
            Long currentEmployeeId) {

        employeeRepository
                .findByEmail(email)
                .ifPresent(existingEmployee -> {

                    if (currentEmployeeId == null
                            || !existingEmployee.getId()
                            .equals(currentEmployeeId)) {

                        throw new IllegalArgumentException(
                                "Email already exists"
                        );
                    }
                });
    }
}