package com.ejada.employeeleaveattendancesystem.controller;

import com.ejada.employeeleaveattendancesystem.entity.LeaveType;
import com.ejada.employeeleaveattendancesystem.service.LeaveTypeService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.List;

@RestController
@RequestMapping("/leave-types")
public class LeaveTypeController {

    private final LeaveTypeService leaveTypeService;

    public LeaveTypeController(LeaveTypeService leaveTypeService) {
        this.leaveTypeService = leaveTypeService;
    }

    @GetMapping
    public List<LeaveType> getAllLeaveTypes(
            @RequestParam(defaultValue = "id") String sortBy,
            @RequestParam(defaultValue = "asc") String direction) {

        return leaveTypeService.getAllLeaveTypes(sortBy, direction);
    }

    @GetMapping("/{id}")
    public LeaveType getLeaveTypeById(@PathVariable Long id) {
        return leaveTypeService.getLeaveTypeById(id);
    }

    @PostMapping
    public LeaveType createLeaveType(@Valid @RequestBody LeaveType leaveType) {
        return leaveTypeService.createLeaveType(leaveType);
    }

    @PutMapping("/{id}")
    public LeaveType updateLeaveType(
            @PathVariable Long id,
            @Valid @RequestBody LeaveType leaveType) {

        return leaveTypeService.updateLeaveType(id, leaveType);
    }

    @DeleteMapping("/{id}")
    public String deleteLeaveType(@PathVariable Long id) {

        leaveTypeService.deleteLeaveType(id);
        return "Leave type deleted successfully";
    }

    @PatchMapping("/{id}")
    public ResponseEntity<LeaveType> partiallyUpdateLeaveType(
            @PathVariable Long id,
            @RequestBody Map<String, Object> updates) {

        LeaveType updatedLeaveType =
                leaveTypeService.partiallyUpdateLeaveType(id, updates);

        return ResponseEntity.ok(updatedLeaveType);
    }
}