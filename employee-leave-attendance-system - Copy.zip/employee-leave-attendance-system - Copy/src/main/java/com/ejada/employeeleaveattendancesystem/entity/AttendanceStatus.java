package com.ejada.employeeleaveattendancesystem.entity;

public enum AttendanceStatus {
    PRESENT,
    ABSENT,
    LATE,
    ON_LEAVE
}