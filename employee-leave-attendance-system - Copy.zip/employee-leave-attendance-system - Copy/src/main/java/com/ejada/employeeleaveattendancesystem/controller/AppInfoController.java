package com.ejada.employeeleaveattendancesystem.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.LinkedHashMap;
import java.util.Map;

@RestController
public class AppInfoController {

    private final String companyName;
    private final String trainingProgram;

    public AppInfoController(
            @Value("${app.company.name}") String companyName,
            @Value("${app.training.program}") String trainingProgram) {

        this.companyName = companyName;
        this.trainingProgram = trainingProgram;
    }

    @GetMapping("/app-info")
    public Map<String, String> getApplicationInfo() {

        Map<String, String> info = new LinkedHashMap<>();

        info.put(
                "application",
                "Employee Leave and Attendance Management System"
        );

        info.put(
                "company",
                companyName
        );

        info.put(
                "trainingProgram",
                trainingProgram
        );

        return info;
    }
}