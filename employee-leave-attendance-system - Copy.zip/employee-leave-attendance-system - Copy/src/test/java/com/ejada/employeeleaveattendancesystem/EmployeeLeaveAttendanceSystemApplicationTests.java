package com.ejada.employeeleaveattendancesystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeLeaveAttendanceSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
