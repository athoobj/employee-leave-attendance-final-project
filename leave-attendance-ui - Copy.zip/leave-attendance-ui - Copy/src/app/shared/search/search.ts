import { Component, EventEmitter, Input, Output } from '@angular/core';

import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-search',
  imports: [FormsModule],
  templateUrl: './search.html',
  styleUrl: './search.css',
})
export class Search {
  @Input() keyword = '';

  @Output() search = new EventEmitter<string>();

  submitSearch(): void {
    this.search.emit(this.keyword.trim());
  }
}
