import { Directive, ElementRef, Input, OnChanges, Renderer2 } from '@angular/core';

@Directive({
  selector: '[appHighlight]',
})
export class Highlight implements OnChanges {
  @Input() appHighlight = false;

  constructor(
    private elementRef: ElementRef,
    private renderer: Renderer2,
  ) {}

  ngOnChanges(): void {
    if (this.appHighlight) {
      this.renderer.setStyle(this.elementRef.nativeElement, 'font-weight', '600');

      this.renderer.setStyle(
        this.elementRef.nativeElement,
        'border-left',
        '4px solid currentColor',
      );
    } else {
      this.renderer.removeStyle(this.elementRef.nativeElement, 'font-weight');

      this.renderer.removeStyle(this.elementRef.nativeElement, 'border-left');
    }
  }
}
