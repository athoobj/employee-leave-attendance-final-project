export interface LoginResponse {
  username: string;
  role: string;
  employeeId?: number | null;
}
