export interface LeaveType {
  id?: number;
  name: string;
  description?: string;
  maximumDays: number;
  active: boolean;
}
