export interface Employee {
  id?: number;
  employeeNumber: string;
  fullName: string;
  email: string;
  department: string;
  active: boolean;
}
