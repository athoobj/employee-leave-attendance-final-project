import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';

import { environment } from '../../environments/environment';
import { LoginRequest } from '../models/login-request';
import { LoginResponse } from '../models/login-response';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private readonly apiUrl = `${environment.apiBaseUrl}/auth`;

  constructor(private http: HttpClient) {}

  login(credentials: LoginRequest): Observable<LoginResponse> {
    return this.http.post<LoginResponse>(`${this.apiUrl}/login`, credentials).pipe(
      tap((response) => {
        localStorage.setItem('authUser', JSON.stringify(response));

        const basicAuth = btoa(`${credentials.username}:${credentials.password}`);

        localStorage.setItem('authToken', `Basic ${basicAuth}`);
      }),
    );
  }

  logout(): void {
    localStorage.removeItem('authUser');
    localStorage.removeItem('authToken');
  }

  getCurrentUser(): LoginResponse | null {
    const user = localStorage.getItem('authUser');

    if (!user) {
      return null;
    }

    return JSON.parse(user) as LoginResponse;
  }

  getToken(): string | null {
    return localStorage.getItem('authToken');
  }

  isLoggedIn(): boolean {
    return this.getCurrentUser() !== null;
  }

  getRole(): string | null {
    return this.getCurrentUser()?.role ?? null;
  }

  getUsername(): string | null {
    return this.getCurrentUser()?.username ?? null;
  }

  getEmployeeId(): number | null {
    return this.getCurrentUser()?.employeeId ?? null;
  }
}
