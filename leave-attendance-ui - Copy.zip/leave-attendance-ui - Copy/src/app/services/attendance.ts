import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

import { environment } from '../../environments/environment';
import { Attendance } from '../models/attendance';

@Injectable({
  providedIn: 'root',
})
export class AttendanceService {
  private readonly apiUrl = `${environment.apiBaseUrl}/attendance`;

  constructor(private http: HttpClient) {}

  getAll(sortBy: string = 'id', direction: 'asc' | 'desc' = 'asc'): Observable<Attendance[]> {
    const params = new HttpParams().set('sortBy', sortBy).set('direction', direction);

    return this.http.get<Attendance[]>(this.apiUrl, { params });
  }

  getById(id: number): Observable<Attendance> {
    return this.http.get<Attendance>(`${this.apiUrl}/${id}`);
  }

  getByEmployee(employeeId: number): Observable<Attendance[]> {
    return this.http.get<Attendance[]>(`${this.apiUrl}/employee/${employeeId}`);
  }

  getByDate(date: string): Observable<Attendance[]> {
    const params = new HttpParams().set('date', date);

    return this.http.get<Attendance[]>(`${this.apiUrl}/date`, { params });
  }

  checkIn(employeeId: number): Observable<Attendance> {
    return this.http.post<Attendance>(`${this.apiUrl}/check-in/${employeeId}`, {});
  }

  checkOut(employeeId: number): Observable<Attendance> {
    return this.http.put<Attendance>(`${this.apiUrl}/check-out/${employeeId}`, {});
  }

  markAbsent(employeeId: number, date: string): Observable<Attendance> {
    const params = new HttpParams().set('date', date);

    return this.http.post<Attendance>(`${this.apiUrl}/absent/${employeeId}`, {}, { params });
  }

  update(id: number, attendance: Attendance): Observable<Attendance> {
    return this.http.put<Attendance>(`${this.apiUrl}/${id}`, attendance);
  }

  patch(id: number, attendance: Partial<Attendance>): Observable<Attendance> {
    return this.http.patch<Attendance>(`${this.apiUrl}/${id}`, attendance);
  }

  delete(id: number): Observable<string> {
    return this.http.delete(`${this.apiUrl}/${id}`, {
      responseType: 'text',
    });
  }
}
