import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { environment } from '../../environments/environment';

import { SystemSummary } from '../models/system-summary';
import { PersonalSummary } from '../models/personal-summary';
import { LeaveStatusReport } from '../models/leave-status-report';
import { AttendanceByEmployeeReport } from '../models/attendance-by-employee-report';

@Injectable({
  providedIn: 'root',
})
export class DashboardService {
  private readonly baseUrl = environment.apiBaseUrl;

  constructor(private http: HttpClient) {}

  getFullSummary(): Observable<SystemSummary> {
    return this.http.get<SystemSummary>(`${this.baseUrl}/summary`);
  }

  getPersonalSummary(): Observable<PersonalSummary> {
    return this.http.get<PersonalSummary>(`${this.baseUrl}/dashboard/personal`);
  }

  getLeaveStatusReport(): Observable<LeaveStatusReport> {
    return this.http.get<LeaveStatusReport>(`${this.baseUrl}/summary/leave-status`);
  }

  getAttendanceReport(): Observable<AttendanceByEmployeeReport> {
    return this.http.get<AttendanceByEmployeeReport>(
      `${this.baseUrl}/summary/attendance-by-employee`,
    );
  }
}
