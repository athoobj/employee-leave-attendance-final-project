import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LeaveRequestWorkflow } from './leave-request-workflow';

describe('LeaveRequestWorkflow', () => {
  let component: LeaveRequestWorkflow;
  let fixture: ComponentFixture<LeaveRequestWorkflow>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LeaveRequestWorkflow],
    }).compileComponents();

    fixture = TestBed.createComponent(LeaveRequestWorkflow);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
