import {
  ChangeDetectorRef,
  Component,
  OnInit,
  inject
} from '@angular/core';

import { CommonModule } from '@angular/common';

import { DashboardService } from '../../services/dashboard';
import { AuthService } from '../../services/auth';

import { SystemSummary } from '../../models/system-summary';
import { PersonalSummary } from '../../models/personal-summary';
import { LeaveStatusReport } from '../../models/leave-status-report';
import { AttendanceByEmployeeReport } from '../../models/attendance-by-employee-report';

@Component({
  selector: 'app-dashboard',
  imports: [CommonModule],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.css'
})
export class Dashboard implements OnInit {

  private dashboardService = inject(DashboardService);
  public authService = inject(AuthService);
  private cdr = inject(ChangeDetectorRef);

  systemSummary: SystemSummary | null = null;
  personalSummary: PersonalSummary | null = null;

  leaveStatusReport: LeaveStatusReport | null = null;
  attendanceReport: AttendanceByEmployeeReport | null = null;

  loading = true;
  errorMessage = '';

  ngOnInit(): void {
    this.loadDashboard();
  }

  isPrivilegedRole(): boolean {
    const role = this.authService.getRole();

    return role === 'HR' || role === 'ADMIN';
  }

  loadDashboard(): void {

    this.loading = true;
    this.errorMessage = '';

    if (this.isPrivilegedRole()) {
      this.loadSystemDashboard();
    } else {
      this.loadPersonalDashboard();
    }
  }

  private loadSystemDashboard(): void {

    this.dashboardService.getFullSummary().subscribe({
      next: (data) => {
        this.systemSummary = data;
        this.loading = false;

        this.cdr.detectChanges();
      },
      error: (error) => {
        this.errorMessage =
          error?.error?.message ??
          'Could not load dashboard summary.';

        this.loading = false;

        this.cdr.detectChanges();
      }
    });

    this.dashboardService.getLeaveStatusReport().subscribe({
      next: (data) => {
        this.leaveStatusReport = data;

        this.cdr.detectChanges();
      },
      error: () => {
        console.error('Could not load leave status report.');

        this.cdr.detectChanges();
      }
    });

    this.dashboardService.getAttendanceReport().subscribe({
      next: (data) => {
        this.attendanceReport = data;

        this.cdr.detectChanges();
      },
      error: () => {
        console.error('Could not load attendance report.');

        this.cdr.detectChanges();
      }
    });
  }

  private loadPersonalDashboard(): void {

    this.dashboardService.getPersonalSummary().subscribe({
      next: (data) => {
        this.personalSummary = data;
        this.loading = false;

        this.cdr.detectChanges();
      },
      error: (error) => {
        this.errorMessage =
          error?.error?.message ??
          'Could not load personal summary.';

        this.loading = false;

        this.cdr.detectChanges();
      }
    });
  }
}
