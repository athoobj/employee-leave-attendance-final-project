import { ChangeDetectorRef, Component, OnInit, inject } from '@angular/core';

import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';

import { LeaveTypeService } from '../../services/leave-type';
import { AuthService } from '../../services/auth';

import { LeaveType } from '../../models/leave-type';

@Component({
  selector: 'app-leave-types',
  imports: [CommonModule],
  templateUrl: './leave-types.html',
  styleUrl: './leave-types.css',
})
export class LeaveTypes implements OnInit {
  private leaveTypeService = inject(LeaveTypeService);

  public authService = inject(AuthService);

  private cdr = inject(ChangeDetectorRef);

  leaveTypes: LeaveType[] = [];

  loading = true;

  errorMessage = '';

  ngOnInit(): void {
    this.loadLeaveTypes();
  }

  loadLeaveTypes(): void {
    this.loading = true;

    this.errorMessage = '';

    this.leaveTypeService.getAll().subscribe({
      next: (data) => {
        this.leaveTypes = data;

        this.loading = false;

        this.cdr.detectChanges();
      },

      error: (error: HttpErrorResponse) => {
        this.loading = false;

        const response = error.error as {
          message?: string;
        } | null;

        this.errorMessage = response?.message ?? 'Could not load leave types.';

        this.cdr.detectChanges();
      },
    });
  }
}
